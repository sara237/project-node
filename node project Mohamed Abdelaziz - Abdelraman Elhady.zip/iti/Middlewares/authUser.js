module.exports = {
  auth:function(req,res,next){

    if(req.session.user.userRole != "user"){
      res.send('user is not authenticated, login first');
      return;
    }
    next();
  }
}