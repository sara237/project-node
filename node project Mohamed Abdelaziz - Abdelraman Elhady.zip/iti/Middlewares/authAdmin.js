module.exports = {
    auth: function(req,res,next){

    if(req.session.user.userRole != "admin"){
      res.redirect('please enter valid admin data or login as admin');
      return;
    }
    next();
  }
}
