const express = require('express');
const server = express();
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const expressSession = require('express-session');
const authUser = require('./Middlewares/authUser')
const authAdmin = require('./Middlewares/authAdmin')

mongoose.connect('mongodb://localhost:27017/iti');


server.use(bodyParser.urlencoded({ extended: false }));
server.use(bodyParser.json());


userController = require('./Controllers/userController')
adminController = require('./Controllers/adminController')



server.use(expressSession({
    secret:"vtfgyhujikhdrftgyhu",
    
  }));


server.post('/user/register',  userController.register)
server.post('/user/login',  userController.login)
server.post('/user/addPost',authUser.auth,  userController.addPost)
server.post('/user/addCategory',authUser.auth,  userController.addCategory)
server.post('/user/listPosts',authUser.auth,  userController.listPosts)
server.post('/admin/register',  adminController.register)
server.post('/admin/login',  adminController.login)
server.post('/admin/list',authAdmin.auth,  adminController.listUsers)

var port = 9000;
server.listen(port,()=>{
    console.log("server  on " +port);
});