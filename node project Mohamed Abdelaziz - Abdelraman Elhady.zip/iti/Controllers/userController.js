const userModel = require('../Models/user');
const postModel = require('../Models/post');
const categoryModel = require('../Models/category');

const ObjectId = require('mongoose').Types.ObjectId;

module.exports = {
    register: function (req, res) {
        userModel.create({
            name: req.body.name,
            password: req.body.password,
            email: req.body.email,
            profileImage: req.body.profileImage,
            userRole: "user"

        }, function (err, result) {
            if (err)
                res.json(err)
            req.session.user = result;
            console.log(req.session)
            res.json(result)
        })
    },

    login: function (req, res) {
        userModel.findOne({
            password: req.body.password,
            email: req.body.email,
            userRole: "user"
        }, function (err, result) {
            if (err)
                res.json(err)
            req.session.user = result;
            res.send("Logged in")
        })
    },

    addPost: function (req, res) {
        console.log(req.session)
        postModel.create({
            title: req.body.title,
            body: req.body.body,
            user: req.session.user,
            category: req.body.category
        }, function (err, result) {
            if (err)
                res.json(err)
            res.json(result)
        })
    },

    addCategory: function (req, res) {
        categoryModel.create({
            name: req.body.name,
        }, function (err, result) {
            if (err)
                res.json(err)
            res.json(result)
        })
    },

    listPosts: function (req, res) {
        postModel.find({
            user: req.session.user._id,
        }, function (err, result) {
            if (err)
                res.json(err)
            res.json(result)
        })
    },



}