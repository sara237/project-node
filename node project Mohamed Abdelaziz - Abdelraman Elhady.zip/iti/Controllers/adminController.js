const userModel = require('../Models/user');

module.exports = {
    listUsers:  function(req,res){
        userModel.find({}, function(err,result){
            if(err)
                res.json(err)
            res.json(result)
        })
    },

    login:  function(req,res){
        userModel.find({
            password: req.body.password,
            email: req.body.email,
            userRole: "admin"
        }, function(err,result){
            if(err)
                res.json(err)
            req.session.user = result;
            res.json(result)
        })
    },

    register: function (req, res) {
        userModel.create({
            name: req.body.name,
            password: req.body.password,
            email: req.body.email,
            profileImage: req.body.profileImage,
            userRole: "admin"
        }, function (err, result) {
            if (err)
                res.json(err)
            req.session.user = result;
            res.json(result)
        })
    },

}