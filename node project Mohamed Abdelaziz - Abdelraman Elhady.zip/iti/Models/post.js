const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = mongoose.Types.ObjectId;

const postSchema = new Schema({
    title: String,
    body: String,
    user:  {
        type : ObjectId,
        ref : "users"
      },
    category:  {
        type : ObjectId,
        ref : "categories"
      },
});

mongoose.model('posts', postSchema);
module.exports = mongoose.model('posts');