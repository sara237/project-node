const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = new Schema({
    name: String,
    password: String,
    email: {
        type : String,
        unique : true
      },
    profileImage: String,
    userRole: String
});

mongoose.model('users', userSchema);

module.exports = mongoose.model('users');
